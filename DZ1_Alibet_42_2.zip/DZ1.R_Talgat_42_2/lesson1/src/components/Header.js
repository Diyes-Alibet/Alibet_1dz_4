import React from 'react';
import Title from "./Title";

const Header = () => {
    return (
        <div>
            <Title title={'Header'} name={'Talgat' +
                ''}/>
        </div>
    );
};

export default Header;