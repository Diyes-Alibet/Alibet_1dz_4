import React from 'react';

const Content = ({text}) => {
    return (
        <div style={{color: 'orange' +
                ''}}>
            {
                text
            }
        </div>
    );
};

export default Content;